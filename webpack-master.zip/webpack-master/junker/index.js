'use strict';

var { krunker } = require('../libs/consts');

if(krunker)require('./main');