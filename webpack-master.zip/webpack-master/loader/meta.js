'use strict';

module.exports = {
	name: `Krunker Cheat Loader`,
	namespace: `https://forum.sys32.dev/`,
	icon: `https://y9x.github.io/webpack/libs/gg.gif`,
	license: 'gpl-3.0',
	version: 1.24,
	match: [ 'https://krunker.io/*', 'https://*.browserfps.com/*' ],
};